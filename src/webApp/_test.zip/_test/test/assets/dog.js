﻿// #include animal.js
console.log('Dog.js 已加载');