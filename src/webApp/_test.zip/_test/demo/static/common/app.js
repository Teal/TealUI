﻿//#import core/core.css
//#include core/core.js
//#include core/class.js
//#include core/date.js
//#include text/tpl.js
//#include text/querystring.js
//#include core/app.js

document.write('<script type="text/javascript" src="../src/core/utility.js"></script>');
document.write('<script type="text/javascript" src="../src/core/class.js"></script>');
document.write('<script type="text/javascript" src="../src/core/app.js"></script>');

document.write('<script type="text/javascript" src="../src/core/date.js"></script>');
document.write('<script type="text/javascript" src="../src/text/tpl.js"></script>');
document.write('<script type="text/javascript" src="../src/text/querystring.js"></script>');

document.write('<script type="text/javascript" src="../src/app/base.js"></script>');