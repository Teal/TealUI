﻿document.write('<script type="text/javascript" src="../../utility/lang/html5.js"></script>');
document.write('<script type="text/javascript" src="../../utility/dom/dom.js"></script>');
