﻿# 数组扩展

## 标准 API

以下 API 由于使用频率高已被移入 [HTML5 兼容补丁](./lang/html5.html#array)。

@api utility/lang/html5.js#Array.isArray,Array.prototype.forEach,Array.prototype.filter,Array.prototype.indexOf

## 常用 API

@api utility/lang/function.js

## 其它 API

@api utility/lang/functionEx.js
