﻿# 日期扩展

@keywords 时间, time, 刚刚, 天前

## 标准 API

以下 API 由于使用频率高已被移入 [HTML5 兼容补丁](./lang/html5.html#function)。

@api utility/lang/html5.js#Function.prototype.bind

## 常用 API

@api utility/lang/html5.js#Function.prototype.bind

## 其它 API

@api utility/lang/dateEx.js

## 格式化时间

@api utility/lang/formatTime.js
