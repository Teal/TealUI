﻿# 布尔扩展

## 常用 API

@api utility/lang/boolean.js