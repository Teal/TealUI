﻿# 数字扩展

## 常用 API

@utility/lang/number.js

## 其它 API

@utility/lang/numberEx.js
