﻿# 日期扩展

@keywords 时间, time, 刚刚, 天前

## 常用 API

@api utility/lang/date.js

## 其它 API

@api utility/lang/dateEx.js

## 格式化时间

@api utility/lang/formatTimeToChinese.js
